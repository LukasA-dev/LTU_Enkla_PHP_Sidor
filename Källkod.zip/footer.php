<?php
echo '<footer>';
echo 'Luleå Tekniska Universitet | Webbutveckling II - Skriptspråk och databaser | lukand-2 | ' . date("Y-m-d");
echo '</footer>';
