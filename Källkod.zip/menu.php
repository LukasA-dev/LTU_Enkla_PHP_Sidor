<nav class="menu">
    <ul>
        <li><a href="sida1.php">Sida 1</a></li>
        <li><a href="sida2.php">Sida 2</a></li>
        <li><a href="sida3.php">Sida 3</a></li>
        <li><a href="sida4.php">Sida 4</a></li>
        <li><a href="sida5.php">Sida 5</a></li>
        <li><a href="sida6.html">Sida 6</a></li>
        <li><a href="sida6.php">Sida 6 PHP</a></li>
    </ul>
</nav>